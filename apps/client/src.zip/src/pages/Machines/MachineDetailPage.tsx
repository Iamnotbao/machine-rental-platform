import { useParams } from 'react-router-dom';

import { Button } from '@machine-rental/ui';

import { machineConfigs } from '@/features/machines/data/machine-config.mock';

import { machineInstances } from '@/features/machines/data/machine-instance.mock';

import { MachineInstanceCard } from '@/features/machines/components/MachineInstanceCard/MachineInstanceCard';

import styles from './page.module.css';

export function MachineDetailPage() {
  const { id } = useParams();

  const config = machineConfigs.find((item) => item.id === id);

  if (!config) {
    return <div>Không tìm thấy cấu hình máy</div>;
  }

  const availableMachines = machineInstances.filter(
    (machine) => machine.configId === config.id && machine.status === 'available',
  );

  return (
    <section>
      <h1>{config.name}</h1>

      <p>{config.description}</p>

      <div className={styles.specs}>
        <p>
          CPU:
          <strong>{config.specs.cpu}</strong>
        </p>

        <p>
          RAM:
          <strong>{config.specs.ram}</strong>
        </p>

        <p>
          GPU:
          <strong>{config.specs.gpu}</strong>
        </p>

        <p>
          SSD:
          <strong>{config.specs.storage}</strong>
        </p>
      </div>

      <h2>Máy đang khả dụng</h2>

      <p>Có {availableMachines.length} máy đang sẵn sàng</p>

      <div className={styles.grid}>
        {availableMachines.map((machine) => (
          <MachineInstanceCard
            key={machine.id}

            machine={machine}
          />
        ))}
      </div>
    </section>
  );
}
